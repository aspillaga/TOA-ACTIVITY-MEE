## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----install, eval=FALSE------------------------------------------------------
# # Install from GitHub
# devtools::install_github("aspillaga/activityTOA", build_vignettes = TRUE)

## ----dataset, message=FALSE---------------------------------------------------
library(activityTOA)

# Set global options to show three millisecond digits
options(digits.secs = 3)

data(fish_data)
names(fish_data)

## ----deployments--------------------------------------------------------------
table(fish_data$detection_data$fish_id, fish_data$detection_data$deployment_id)

## ----subset-------------------------------------------------------------------
# Select fish and deployment IDs and subset detection data
fish <- "CORHIP-892"
depl <- 42
data <- fish_data$detection_data[fish_id == fish & deployment_id == depl]
head(data)

# Number of detections
nrow(data)

# Date range (for plots)
date_range <- c(floor_date(min(data$date_time), "days") - 24*3600, 
                ceiling_date(max(data$date_time), "days") + 24*3600)
dates <- seq(date_range[1], date_range[2], "days")
date_range

## ----fracSec, out.width="80%", fig.align="center"-----------------------------
# Extract fractional seconds
data[, fs := fractSec(date_time)]

# Plot fractional seconds against time
plot(fs ~ date_time, data = data, pch = 16, col = "#0C3096", cex = 0.4, 
     ann = FALSE, axes = FALSE)
axis(1, at = dates, lwd = 0, lwd.ticks = 1, labels = format(dates, "%b-%d"))
axis(2, lwd = 0, lwd.ticks = 1, las = 1)
title(xlab = "Date time", line = 2.6)
title(ylab = "Seconds (0-1 constrained)", line = 2.8)
box()

## ----unwrap, out.width="80%", fig.align="center"------------------------------
# Select the granularity of the transmitter from tag metadata
indx_id <- fish_data$tag_metadata$fish_id == fish
gran <- fish_data$tag_metadata$granularity[indx_id]
gran # Granularity of 1 s

# Unwrap the drift
data[, drift := unwrapDrift(fs, date_time, gran)]

# Plot unwrapped drift against time
plot(drift ~ date_time, data = data,  pch = 16, col = "#0C3096", cex = 0.4, 
     axes = FALSE, xlab = "Date time", ylab = "Seconds")
axis(1, at = dates, lwd = 0, lwd.ticks = 1, labels = format(dates, "%b-%d"))
axis(2, lwd = 0, lwd.ticks = 1)
box()

## ----spline, out.width="80%", fig.align="center"------------------------------
# Set degrees of freedom based on the number of days with detections
df <- ceiling(length(unique(as.Date(data$date_time)))/2)
df # 7 degrees of freedom

# Fit cubic smoothing spline
spl <- smooth.spline(data$date_time, data$drift, df = df)

# Plot spline over unwrapped drift
plot(drift ~ date_time, data = data,  pch = 16, col = "#0C3096", cex = 0.4, 
     axes = FALSE, xlab = "Date time", ylab = "Seconds")
axis(1, at = dates, lwd = 0, lwd.ticks = 1, labels = format(dates, "%b-%d"))
axis(2, lwd = 0, lwd.ticks = 1)
lines(spl, col = "#FC3508", lwd = 3)
legend("topright", legend = paste0("Spline (df=", df, ")"), lwd = 3, 
       col = "#FC3508", bty = "n")
box()

# Compute TOAs as residuals from the spline
data[, toa := resid(spl)]

# Plot TOA values against time
plot(toa ~ date_time, data = data, pch = 16, col = "#0C3096", cex = 0.4,
     axes = FALSE, xlab = "Date time", ylab = "TOA (seconds)")
axis(1, at = dates, lwd = 0, lwd.ticks = 1, labels = format(dates, "%b-%d"))
axis(2, lwd = 0, lwd.ticks = 1)
box()

## ----dist, out.width="80%", fig.align="center"--------------------------------
# Extract temperature log for the receiver
sensor <- fish_data$sensor_data[deployment_id == unique(data$deployment_id)]

# Assign temperature data to each detection by matching to 10-minute intervals
indx <- match(floor_date(data$date_time, "10min"), sensor$date_time)
data$temperature_receiver <- sensor$temperature[indx]

# Calculate the speed of sound at each detection
data[, sound_speed := soundSpeed(temperature_receiver, sal = 37, depth = 5)]

# Estimate relative distances (TOA*sound speed), then offset to 0 by subtracting
# the minimum value
data[, dist := toa * sound_speed]
data[, dist := dist - min(dist, na.rm = TRUE)]

# Maximum estimated distance from the receiver
max(data$dist) # ~280 m

# Plot distance values against time
plot(dist ~ date_time, data = data, pch = 16, col = "#0C3096", cex = 0.4,
     axes = FALSE, xlab = "Date time", ylab = "Distance to receiver (m)")
axis(1, at = dates, lwd = 0, lwd.ticks = 1, labels = format(dates, "%b-%d"))
axis(2, lwd = 0, lwd.ticks = 1)
box()

## ----snr, out.width="80%", fig.align="center"---------------------------------
# Plot SNR vs estimated distance to the receiver
plot(snr ~ dist, data = data, pch = 16, col = "#0C3096", cex = 0.4,
     axes = FALSE, xlab = "Distance to receiver (m)", ylab = "SNR")
axis(1, lwd = 0, lwd.ticks = 1)
axis(2, lwd = 0, lwd.ticks = 1)
box()

## ----step, out.width="80%", fig.align="center"--------------------------------
# Calculate step lengths (differences between consecutive distances)
data[, step := c(NA, diff(dist))]

# Plot step lengths over time
plot(step ~ date_time, data = data, pch = 16, col = "#0C3096", cex = 0.4,
     axes = FALSE, xlab = "Date time", ylab = c("Step length (m)"))
axis(1, at = dates, lwd = 0, lwd.ticks = 1, labels = format(dates, "%b-%d"))
axis(2, lwd = 0, lwd.ticks = 1, las = 1)
title(xlab = "Date time", line = 3)
title(ylab = "Step length (m)", line = 3)
box()

## ----abs_step, out.width="80%", fig.align="center"----------------------------
# Plot absolute step lengths against time
plot(abs(step) ~ date_time, data = data, pch = 16, col = "#0C3096", cex = 0.4,
     axes = FALSE, xlab = "Date time", ylab = "Absloute step length (m)")
axis(1, at = dates, lwd = 0, lwd.ticks = 1, labels = format(dates, "%b-%d"))
axis(2, lwd = 0, lwd.ticks = 1)
box()

## ----step_bin, out.width="80%", fig.align="center"----------------------------
# Aggregate detections into 5-minute intervals and calculate mean distances
data[, time_int := floor_date(date_time, "5min")]
data_t <- data[, .(n = length(tag_id), dist = mean(dist, na.rm = TRUE)),
               by = list(date_time = time_int)]

# Estimate step lengths between consecutive time intervals
data_t[, step := c(NA, abs(diff(dist)))]

# Plot step lengths in 5-minute intervals
plot(step ~ date_time, data = data_t, pch = 16, col = "#0C3096", cex = 0.4,
     axes = FALSE, xlab = "Date time", ylab = "Step length (m)")
axis(1, at = dates, lwd = 0, lwd.ticks = 1, labels = format(dates, "%b-%d"))
axis(2, lwd = 0, lwd.ticks = 1, las = 1)
box()

## ----sun----------------------------------------------------------------------
library(suncalc)

# Deployment coordinates
coord <- fish_data$deployment_metadata[deployment_id == depl,
                                       c(longitude, latitude)]

# Get sunrise/sunset times for each day at deployment coordinates
sun <- getSunlightTimes(as.Date(dates), lat = coord[1], lon = coord[2], 
                        keep = c("sunrise", "sunset"))
head(sun)

# Assign day/night labels to each time interval
indx_dn <- match(as.Date(data_t$date_time), sun$date)
data_t$daynight <- ifelse(data_t$date_time >= sun$sunrise[indx_dn] &
                            data_t$date_time <= sun$sunset[indx_dn],
                          "day", "night")
data_t$daynight <- factor(data_t$daynight, levels = c("day", "night"))

## ----prep_data, out.width="80%", fig_height = 6, fig.align="center", message=FALSE, warning=FALSE----
library(momentuHMM)

# Prepare data for momentuHMM
data_hmm <- prepData(data_t, coordNames = NULL, covNames = "step")

# Visualise distribution of step lengths
hist(data_hmm$step, breaks = 500, col = "gray40", border = "transparent",
     xlab = "Step length (m)", main = "")
box()

# Define model parameters
states <- c("Resting", "Active") # Name of the states
state_col <-  c(Resting = "#04AA96", Active = "#EA9D03") # Colors for plots
distrib <- list(step = "gamma") # Parameter distribution
par0 <- list(step = c(2, 20,  # Initial parameters for mean step lengths
                      2, 20)) # Initial parameters for standard deviations

# Show starting values in the histogram
abline(v = par0$step[c(1, 2)], col =  state_col, lwd = 2)
legend("topright", legend = names(state_col), lwd = 2, col = state_col, 
       inset = c(0.05, 0.05), title = "Starting values")

# Fit the HMM with day/night as a covariate on transition probabilities
hmm_dn <- fitHMM(data = data_hmm, nbStates = length(states), 
                 stateNames = states, dist = distrib, Par0 = par0, 
                 formula = ~daynight)

# Display and plot results
hmm_dn

plot(hmm_dn, breaks = 100, ask = FALSE)

## ----plot_states, fig.width = 10, fig.height = 6, out.width="100%", fig.align="center"----
# Decode most probable state sequence
data_t$state <- viterbi(hmm_dn)

# Function to shade nighttime periods in plots using sunrise/sunset data
plotSun <- function(sun, night_col = "#D3DAE2") {
  usr <- par("usr")
  rect(xleft = sun$sunset[-nrow(sun)], xright = sun$sunrise[-1], 
       ybottom = usr[3], ytop = usr[4], col = night_col, border = "transparent")
}

par(mfrow = c(2, 1), mar = c(0, 4.5, 0.5, 1.1), oma = c(4.1, 0, 0, 0))

# Plot distance over time
plot(dist ~ date_time, data = data_t, type = "n", axes = FALSE, ann = FALSE)
plotSun(sun)
lines(dist ~ date_time, data = data_t, col = "#01415B", lwd = 1)
points(dist ~ date_time, data = data_t, cex = 0.5, pch = 16, 
       col = state_col[state])
axis(2, lwd = 0, lwd.ticks = 1, las = 1)
title(ylab = "Distance to receiver (m)", line = 3.1)
legend("topright", legend = names(state_col), pch = 16, col = state_col, 
       inset = c(0.06, 0.05), cex = 0.8, bg = "white")
box()

# Plot step lengths over time
plot(step ~ date_time, data = data_t, type = "n", axes = FALSE, ann = FALSE)
plotSun(sun)
lines(step ~ date_time, data = data_t, col = "#01415B", lwd = 1)
points(step ~ date_time, data = data_t, cex = 0.5, pch = 16, 
       col = state_col[state])
axis(1, at = dates, lwd = 0, lwd.ticks = 1, labels = format(dates, "%b-%d"))
axis(2, lwd = 0, lwd.ticks = 1, las = 1)
title(ylab = "Step length (m)", line = 3.1)
legend("topright", legend = names(state_col), pch = 16, col = state_col, 
       inset = c(0.06, 0.05), cex = 0.8, bg = "white")
box()

## ----multiple_toa-------------------------------------------------------------
# Select the entire detection dataset
detect <- fish_data$detection_data

# Extract fractional seconds
detect[, fs := fractSec(date_time)]

# Assign the tag granularity value to each detection to facilitate group-wise 
# operations in the next step
indx_g <- match(detect$fish_id, fish_data$tag_metadata$fish_id)
detect$gran <- fish_data$tag_metadata$granularity[indx_g]

# Apply the unwrapping function separately for each fish_id and deployment_id
detect[, drift := unwrapDrift(fs, date_time, unique(gran)),
       by = list(fish_id, deployment_id)]

# Helper function to extract TOAs by fitting a smoothing spline to the drift 
# signal. The spline's degrees of freedom (df) can be manually set, or 
# automatically estimated as a fraction (f) of the number of unique detection 
# days (this functionality has been added to test the effect of different df 
# values in the next section)
extractTOA <- function(drift, time.stamps, df = NULL, f = 0.5) {
  if (is.null(df)) df <- ceiling(length(unique(as.Date(time.stamps)))*f)
  spl <- smooth.spline(time.stamps, drift, df = df)
  resid <- drift - predict(spl, x = as.numeric(time.stamps))$y
  return(resid)
}

# Estimate TOAs for each fish_id and deployment_id combination. The df is set to
# half the number of unique detection days (f = 0.5).
detect[, toa1 := extractTOA(drift, date_time, df = NULL, f = 0.5),
       by = list(fish_id, deployment_id)]

## ----plot_multi, fig.width = 10, fig.height = 10, out.width = "100%", fig.align = "center"----
# Select three individuals
id_list <- c("CONTAG-106", "CORHIP-892", "EPIMAR-5018", "GYMALT-5044")

# Plot the first three days of data for each individual
par(mfrow = c(4, 3), mar = c(4.1, 4.1, 1, 2), oma = c(0, 3, 3, 0))
for (id in id_list) {
  det_sub <- detect[fish_id == id][date_time < date_time[1] + 3*24*3600]
  plot(fs ~ date_time, data = det_sub, pch = 16, col = "#0C3096", cex = 0.4,
       xlab = "", ylab = "Seconds")
  plot(drift ~ date_time, data = det_sub, pch = 16, col = "#0C3096", cex = 0.4,
       xlab = "", ylab = "Seconds")
  plot(toa1 ~ date_time, data = det_sub, pch = 16, col = "#0C3096", cex = 0.4,
       xlab = "", ylab = "TOA (seconds)")
}
mtext(c("Fractional seconds (0-1 constrained)", "Unwrapped drift",
        "TOA"), side = 3, outer = T, at = c(0.17, 0.50, 0.85), font = 2)
mtext(id_list, side = 2, outer = T, at = c(0.90, 0.65, 0.4, 0.15), font = 2,
      padj = -1)

## ----df_test, fig.width = 8, fig.height = 12, out.width="100%", fig.align="center"----
# Add temperature values from sensor data to each detection
indx_t <- match(paste0(floor_date(detect$date_time, "10min"), 
                       detect$deployment_id),
                paste0(fish_data$sensor_data$date_time, 
                       fish_data$sensor_data$deployment_id))
detect[, temperature_receiver := fish_data$sensor_data$temperature[indx_t]]

# Add salinity and depth information from deployment metadata
indx_d <- match(detect$deployment_id, 
                fish_data$deployment_metadata$deployment_id)
detect[, salinity := fish_data$deployment_metadata$salinity_psu[indx_d]]
detect[, depth := fish_data$deployment_metadata$depth[indx_d]]

# Estimate sound speed for each detection
detect[, sound_speed := soundSpeed(temperature_receiver, salinity, depth)]

# Detrend using different spline df settings and compute TOA-based distances ---

# Recommended: df = 0.5 x detection days (from the previous section)
detect[, dist1 := toa1 * sound_speed]
detect[, step1 := c(diff(dist1), NA), by = list(fish_id, deployment_id)]

# Linear approach: df = 2
detect[, toa2 := extractTOA(drift, date_time, df = 2),
       by = list(fish_id, deployment_id)]
detect[, dist2 := toa2 * sound_speed]
detect[, step2 := c(diff(dist2), NA), by = list(fish_id, deployment_id)]

# Flexible fit: df = 2 x detection days
detect[, toa3 := extractTOA(drift, date_time, f = 2),
       by = list(fish_id, deployment_id)]
detect[, dist3 := toa3 * sound_speed]
detect[, step3 := c(diff(dist3), NA), by = list(fish_id, deployment_id)]

# Very flexible fit: df = 10 x detection days
detect[, toa4 := extractTOA(drift, date_time, f = 10),
       by = list(fish_id, deployment_id)]
detect[, dist4 := toa4 * sound_speed]
detect[, step4 := c(diff(dist4), NA), by = list(fish_id, deployment_id)]

# Visual comparison of distance and step lengths for different df values
par(mfrow = c(4, 2), mar = c(4.8, 4.8, 1.8, 1), oma = c(0, 0, 3.5, 0))

for (id in id_list) {
  det_sub <- detect[fish_id == id]
  n_days <- length(unique(as.Date(det_sub$date_time)))
  
  ylim_dist <- range(c(det_sub$dist1, det_sub$dist2, det_sub$dist3, 
                       det_sub$dist4), na.rm = T)
  ylim_step <- range(c(det_sub$step1, det_sub$step2, det_sub$step3,
                       det_sub$dist4), na.rm = T)
  
  df_val <- c(2, ceiling(n_days*0.5), ceiling(n_days*2), ceiling(n_days*10))
  df_id <- c(2, 1, 3, 4)
  
  for (i in seq_along(df_val)) {
    plot(formula(paste0("dist", df_id[i], " ~ date_time")), data = det_sub, 
         pch = 16, col = "#0C3096", cex = 0.4, xlab = "", 
         ylab = "Distance to receiver (m)", ylim = ylim_dist)
    title(paste("n days =", n_days, "  ", "df =", df_val[i]), font.main = 1, 
          adj = 1)
  
    plot(formula(paste0("step", df_id[i], " ~ date_time")), data = det_sub, 
         pch = 16, col = "#0C3096", cex = 0.4, xlab = "", 
         ylab = "Step length (m)", ylim = ylim_step)
    title(paste("n days =", n_days, "  ", "df =", df_val[i]), font.main = 1, 
          adj = 1)
  }
  
  title(main = id, outer = TRUE)    
}

## ----df_test_2, fig.width = 8, fig.height = 3, out.width="100%", fig.align="center"----
# Compare step lengths across df settings to test consistency of movement 
# estimation
par(mfrow = c(1, 3), mar = c(4.8, 4.8, 1, 1), oma = c(0, 0, 0, 0))

df_lab <- c(2, "Detect. days x 2", "Detect. days x 10")
df_id <- c(2, 3, 4)

for (i in seq_along(df_lab)) {
  plot(formula(paste0("step", df_id[i], "~ step1")), data = detect, 
       col = adjustcolor("#0C3096", 0.6), pch = 16,
       xlab ="Step lengths (m); df = Detect. days / 2",
       ylab = paste("Step lengths (m); df =", df_lab[i]))
  abline(0, 1, col = "red", lwd = 2)
}

